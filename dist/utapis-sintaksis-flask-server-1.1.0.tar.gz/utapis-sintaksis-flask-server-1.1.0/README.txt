Modul Python 'utapis-flask-server' digunakan untuk memberikan akses ke 
API ke algoritma U-Tapis pengecekan sintaksis kalimat (CRF + CFG) dengan
menggunakan Flask.

Modul ini TIDAK BOLEH DIBAGIKAN UNTUK PUBLIK!