Modul Python 'utapis-sintaksis-flask-server' digunakan untuk memberikan akses ke 
API ke Algoritma U-Tapis Pendeteksi Kesalahan Sintaksis Kalimat (CRF + CFG) dengan
menggunakan Python Flask Server. 

Modul ini juga digunakan sebagai proyek skripsi Denn Sebastian Emmanuel di Universitas Multimedia Nusantara

Dilarang menggandakan atau menggunakan kode-kode di dalam proyek ini tanpa izin dari pembuat kode (denn-acrymoore).
